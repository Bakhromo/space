from django.contrib import admin
from .models import New, UserProfile
# Register your models here.

admin.site.register(New)
admin.site.register(UserProfile)